namespace layout
{
    public partial class CrearContacto : ContentPage
    {
    	public CrearContacto()
    	{
    		InitializeComponent();
    	}
    }
}